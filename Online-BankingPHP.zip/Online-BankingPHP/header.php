<link rel="stylesheet" type="text/css" href="css/header.css">
        <div class="header_main">
		<div class="navBar">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact Us</a></li>
				<li><a href="staff_login.php">Staff Login</a></li>
			
			</ul>
		</div>
	 <a href="index.php"><div class="logo-name">
			<div class="logo">
             <img class="logo_img" src="img/chase.jpg">
			</div>
			
			<div class="name">
				<h5> Online Banking System</h5></a><br>
				<h6>In PHP</h6>
			</div>
        </div>
            
            
            <div class="dif_banking">
			<div class="retail_banking">
				<a href="#">Retail Banking</a>
			</div>
			<div class="corporate_banking">
				<a href="#"> Corporate Banking</a>
			</div>
			<div class="international_banking">
				<a href="#"> International Banking</a>
			</div>
			<div class="international_banking">
				<a href="#"> Apply Mobile Banking</a>
			</div>
                
            <div class="bank_servic">
				<a href="#">Services</a>
			</div>
		</div>
            
           
			
	</div>